<?php

//heading
$_['heading_title']              = '<b><span style="color:#449DD0; font-weight:bold">Category showcase</span><span style="font-size:12px; color:#999"> by <a href="http://www.opencart.com/index.php?route=extension/extension&amp;filter_username=Dreamvention" style="font-size:1em; color:#999" target="_blank">Dreamvention</a></span></b>';
$_['text_success']               = "Module has been update";
$_['text_module']                = 'Modules';
$_['heading_title_main']         = 'Category showcase';
$_['entry_category']             = 'Categories';

$_['text_edit']                  = 'Edit';
$_['text_enabled']               = 'Enable';
$_['text_disabled']              = 'Disable';
$_['text_save_and_stay']         = 'Save and stay';
$_['text_edit']                  = 'Edit';


$_['entry_show_images']          = "Show images";
$_['show_images_enabled']        = 'Yes';
$_['show_images_disabled']       = 'No';

$_['entry_count_products']       = "Count products";
$_['count_products_enabled']     = 'Yes';
$_['count_products_disabled']    = 'No';


